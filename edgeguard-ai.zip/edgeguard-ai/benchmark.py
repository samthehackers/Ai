#!/usr/bin/env python3
"""CPU latency + memory benchmark of one or more ONNX models. RUN THIS ON THE RASPBERRY PI 5 to get deployment numbers.
Results record the host so desktop numbers can never be mistaken for Pi numbers.

  python benchmark.py models/best.onnx models/other.onnx --runs 100 --out evaluation/benchmark.json
"""
import argparse, json, os, platform, time
import numpy as np, psutil, onnxruntime as ort


def host():
    model = ''
    try: model = open('/proc/device-tree/model').read().strip('\x00')
    except OSError: pass
    return dict(machine=platform.machine(), system=platform.platform(), cpu_count=os.cpu_count(), device_tree_model=model,
                is_raspberry_pi_5='Raspberry Pi 5' in model)


def bench(path, runs, warm, threads):
    so = ort.SessionOptions(); so.intra_op_num_threads = threads
    p = psutil.Process(); before = p.memory_info().rss
    s = ort.InferenceSession(path, so, providers=['CPUExecutionProvider'])
    i = s.get_inputs()[0]; sz = int(i.shape[2]) if isinstance(i.shape[2], int) else 640
    x = np.random.RandomState(0).rand(1, 3, sz, sz).astype(np.float32)   # latency is input-content independent
    for _ in range(warm): s.run(None, {i.name: x})
    t = []
    for _ in range(runs):
        t0 = time.perf_counter(); s.run(None, {i.name: x}); t.append((time.perf_counter() - t0) * 1000)
    t = np.array(t)
    return dict(model=path, size_mb=round(os.path.getsize(path) / 1e6, 2), imgsz=sz, runs=runs, threads=threads,
                latency_ms=dict(mean=round(t.mean(), 1), p50=round(float(np.percentile(t, 50)), 1), p95=round(float(np.percentile(t, 95)), 1), max=round(t.max(), 1)),
                fps_model_only=round(1000 / t.mean(), 2), rss_delta_mb=round((p.memory_info().rss - before) / 1e6, 1), rss_total_mb=round(p.memory_info().rss / 1e6, 1))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('models', nargs='+'); ap.add_argument('--runs', type=int, default=100)
    ap.add_argument('--warmup', type=int, default=10); ap.add_argument('--threads', type=int, default=4); ap.add_argument('--out')
    a = ap.parse_args(); h = host()
    res = dict(host=h, results=[bench(m, a.runs, a.warmup, a.threads) for m in a.models])
    if not h['is_raspberry_pi_5']: res['warning'] = 'NOT a Raspberry Pi 5: these numbers are not Pi benchmarks.'
    print(json.dumps(res, indent=2))
    if a.out: json.dump(res, open(a.out, 'w'), indent=2)
