#!/usr/bin/env bash
# Installs the systemd service (starts at boot) AND, by default, opens the dashboard full-screen after you sign in.
# Usage: ./setup.sh [--no-kiosk]
set -euo pipefail
cd "$(dirname "$0")"; chmod +x scripts/*.sh ./*.sh 2>/dev/null || true; DIR="$(pwd)"; RUN_USER="${SUDO_USER:-$USER}"
[ -x .venv/bin/python ] || { echo "run ./install.sh first"; exit 1; }
[ -f models/best.onnx ] || echo "WARNING: models/best.onnx missing. The service will start but report MODEL_UNAVAILABLE (never 'safe') until you add it."
[ -f edgeguard.env ] || { printf '# Optional secrets (chmod 600). Telegram is optional; detection works offline without it.\n#EDGEGUARD_TOKEN=change-me\n#EDGEGUARD_TG_TOKEN=\n#EDGEGUARD_TG_CHAT=\n' > edgeguard.env; chmod 600 edgeguard.env; }
sed -e "s|@DIR@|$DIR|g" -e "s|@USER@|$RUN_USER|g" scripts/edgeguard.service | sudo tee /etc/systemd/system/edgeguard.service >/dev/null
sudo usermod -aG video,audio "$RUN_USER" || true
sudo systemctl daemon-reload
sudo systemctl enable --now edgeguard.service
if [ "${1:-}" != "--no-kiosk" ]; then
  # Show the dashboard full-screen on the Pi's own screen at every boot (desktop OS with auto-login required).
  H="$(getent passwd "$RUN_USER" | cut -d: -f6)"
  mkdir -p "$H/.config/autostart" "$H/.config/labwc"
  printf '[Desktop Entry]\nType=Application\nName=EDGEGUARD Dashboard\nExec=/bin/bash %s/scripts/kiosk.sh\n' "$DIR" > "$H/.config/autostart/edgeguard-kiosk.desktop"
  grep -q 'edgeguard' "$H/.config/labwc/autostart" 2>/dev/null || echo "/bin/bash $DIR/scripts/kiosk.sh &" >> "$H/.config/labwc/autostart"
  chown -R "$RUN_USER" "$H/.config/autostart" "$H/.config/labwc"
  echo "Dashboard will open full-screen after sign-in. Make sure Raspberry Pi OS is set to desktop auto-login (sudo raspi-config -> System Options -> Boot / Auto Login)."
fi
echo "Service installed. Status:  systemctl status edgeguard    Logs:  journalctl -u edgeguard -f    Dashboard:  http://$(hostname -I | awk '{print $1}'):8080"
