# EDGEGUARD AI

Local, offline child-safety hazard monitor for Raspberry Pi 5. Camera -> ONNX Runtime detector -> risk engine -> alerts -> web dashboard.
It is an **assistive tool**: it can miss hazards and raise false alarms, does not replace adult supervision, and is not guaranteed to prevent accidents.

## Status (honest)
| Component | Status |
|---|---|
| Dataset audit, label normalisation, YOLO conversion, duplicate-safe split | Built, tested, audit run on the real export |
| Risk engine, ONNX inference, camera recovery, alerts, SQLite log, optional Telegram, dashboard/API, systemd unit | Built; **53 automated tests pass** (using a fixture ONNX that emits fixed tensors, so they test plumbing, not accuracy) |
| Training, evaluation (mAP, F1, confusion, FP/FN), export, INT8, plots | Written, **not executed**: the images and a trained model were not supplied |
| Model accuracy, file sizes, Pi 5 latency/RAM | **Pending** (no numbers exist; none are invented) |
| Drop folder, optional OpenRouter / local-LLM second opinion | Built; covered by tests against a local fake OpenAI-compatible server (real OpenRouter/Ollama not called from here) |
| Installation on a real Pi, systemd boot start | Scripts syntax-checked, graceful SIGTERM verified on a dev machine; **not tested on a Pi** |

See `dataset/FEASIBILITY.md` for the data findings (missing images, 275 conflicting-label files, approach A vs B).

## Quick start
```bash
# (after unzipping: chmod +x *.sh scripts/*.sh   - or just run them with  bash <script>)
# 1. Dataset (on a workstation) - needs the images that /data/upload/2/ refers to
python dataset/prepare_dataset.py --export project.json --audit-only            # audit only (no images needed)
python dataset/prepare_dataset.py --export project.json --images /path/to/images --out dataset/yolo --oversample-rare 60
# 2. Train (workstation; pip install -r requirements-train.txt)
python training/train.py --data dataset/yolo/data.yaml --model yolov8n.pt --epochs 100 --imgsz 640
# 3. Evaluate on the held-out test split, then render figures from real outputs
python export_model.py --weights runs/yolov8n/weights/best.pt --out models/best.onnx
python evaluate.py --model models/best.onnx --data dataset/yolo/data.yaml --split test --out evaluation/results
python evaluation/plot_results.py --run runs/yolov8n --eval evaluation/results --out evaluation/plots
# 4. On the Raspberry Pi 5 (64-bit OS): copy the project + models/best.onnx (+ best.meta.json), then
./install.sh
python benchmark.py models/best.onnx --out evaluation/benchmark_pi5.json     # real Pi numbers; marks non-Pi hosts
./run.sh                    # foreground test, dashboard on http://<pi-ip>:8080
./setup.sh                  # enable start at boot (systemd)
```
Optional INT8: `python export_model.py ... --int8 --calib dataset/yolo/images/val`, then re-run `evaluate.py` on the INT8 file and use it only if accuracy holds.

## Boot, drop folders and the optional LLM
- **Dashboard pops up by itself:** `./install.sh` then `./setup.sh`. The service starts at every power-on (`Restart=always`), and after you sign in on the HDMI screen the dashboard opens full-screen automatically (`scripts/kiosk.sh`; needs the desktop OS with auto-login or a normal login; `--no-kiosk` skips it). The kiosk part could not be tested on a real Pi here.
- **Detection image drop folder:** copy pictures into `inbox/` on the Pi (or use *Analyze images* in the dashboard). Results land in `outbox/` (annotated `.jpg` + `.json`); handled files move to `inbox/processed/`, unreadable ones to `inbox/failed/` with a reason. Single images get no temporal smoothing.
- **Training drop folder:** put training pictures in `training_data/images/` and their YOLO labels in `training_data/labels/` (or a Label Studio JSON). Then `scripts/train_from_dropbox.sh` prepares, trains, exports `models/best.onnx`, evaluates and plots. Unlabelled pictures are excluded and listed, never guessed. See `training_data/README.md`. Train on a GPU machine/Colab, not on the Pi.
- **The detector never depends on an LLM**, online or offline. An LLM only adds a short advisory description to alerts and dropped images, in a background queue; it **cannot lower a risk level or suppress an alert**, and if it fails the detector result stands. LLMs can be wrong.
  - **Online = OpenRouter, only when the Pi has internet:** `scripts/set_openrouter_key.sh` (stores the key in `edgeguard.env`, chmod 600). Default model `google/gemini-2.5-flash` (`mllm.online.model`). Setting the key = consent to send alert/dropped images off-device.
  - **Offline = llama.cpp:** `scripts/install_llamacpp.sh` (run once while online) builds llama.cpp, downloads a small vision model (default `ggml-org/SmolVLM-500M-Instruct-GGUF`, or pass another Hugging Face GGUF repo), runs `llama-server` as `edgeguard-llama.service` on port 8081 at low priority/2 threads, then pins the cached files so later boots need no internet.
  - **Selection (`mllm.mode: auto`):** internet + key -> OpenRouter; otherwise local llama.cpp if its server is running; otherwise detector only. `online`, `offline` or `off` force a mode.

## Safety design
- States: `HIGH`, `LOW`, `UNCERTAIN`, `NO_RISK`. Uncertain detections are never reported as safe; a confident "no risk" class overlapping a weaker HIGH/LOW becomes `UNCERTAIN`.
- Temporal smoothing: HIGH needs `high_hits` of the last `window` inferences; de-escalation needs the evidence to age out plus `clear_frames` calm frames.
- Camera down, stream ended, model missing or inference error shows `NO SAFETY SIGNAL`, never `NO_RISK`.
- Proximity is only an image-plane hint (gap / toddler height). A single uncalibrated camera cannot give distance.
- Alerts: cooldowns (HIGH 30 s, LOW 120 s), local beep via `aplay`, event log in `logs/events.db`, snapshots, optional Telegram (failures never affect detection).

## Configuration and API
`config.yaml` (thresholds, camera source: USB index / file / RTSP / `picamera2`, cooldowns). Thresholds can be changed live in the dashboard; set `EDGEGUARD_TOKEN` in `edgeguard.env` to require `X-Auth-Token` for changes. The service listens on all interfaces: use only on a trusted LAN or behind a firewall.
`GET /api/status`, `/api/events`, `/api/config` (POST to change), `/video_feed`, `/health`.

## Tests
`python -m pytest tests -q` (dataset conversion/dedupe/leakage, risk logic, decoding/NMS, alerts, camera recovery, app end to end).

## Layout
`dataset/` audit + conversion, `training/train.py`, `export_model.py`, `evaluate.py`, `benchmark.py`, `inference.py`, `risk_engine.py`, `camera.py`, `alerts.py`, `app.py`, `dashboard/`, `configs/classes.yaml`, `config.yaml`, `scripts/edgeguard.service`, `evaluation/plot_results.py`, `tests/`.
