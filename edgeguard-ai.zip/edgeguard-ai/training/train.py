#!/usr/bin/env python3
"""Reproducible YOLO training (Ultralytics). Approach A: the six toddler-near-hazard risk classes + person/hazard classes.

  python training/train.py --data dataset/yolo/data.yaml --model yolov8n.pt --epochs 100 --imgsz 640
Pretrained weights are downloaded once by Ultralytics (needs internet at TRAINING time only; the Pi never needs it).
Writes runs/<name>/ with weights, results.csv, curves, and train_config.json (seed + args + versions).
"""
import argparse, json, os, platform, sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', required=True); ap.add_argument('--model', default='yolov8n.pt')
    ap.add_argument('--epochs', type=int, default=100); ap.add_argument('--imgsz', type=int, default=640)
    ap.add_argument('--batch', type=int, default=16); ap.add_argument('--device', default='')
    ap.add_argument('--seed', type=int, default=0); ap.add_argument('--patience', type=int, default=30)
    ap.add_argument('--project', default='runs'); ap.add_argument('--name', default=None)
    ap.add_argument('--resume', action='store_true')
    a = ap.parse_args()
    from ultralytics import YOLO
    import ultralytics, torch
    name = a.name or os.path.splitext(os.path.basename(a.model))[0]
    m = YOLO(a.model)
    m.train(data=a.data, epochs=a.epochs, imgsz=a.imgsz, batch=a.batch, device=a.device or None, seed=a.seed, deterministic=True,
            patience=a.patience, project=a.project, name=name, exist_ok=True, resume=a.resume, save_period=5,   # checkpoints
            # Augmentation. No vertical flip (children/knives/irons are upright in this data). Horizontal flip is safe
            # because risk depends on proximity, not on left/right. Mosaic helps small datasets.
            hsv_h=0.015, hsv_s=0.6, hsv_v=0.4, degrees=5, translate=0.1, scale=0.4, fliplr=0.5, flipud=0.0, mosaic=1.0, mixup=0.0,
            close_mosaic=10, plots=True)
    out = os.path.join(a.project, name)
    json.dump(dict(args=vars(a), ultralytics=ultralytics.__version__, torch=torch.__version__, python=sys.version, platform=platform.platform()),
              open(os.path.join(out, 'train_config.json'), 'w'), indent=2)
    print('best weights:', os.path.join(out, 'weights', 'best.pt'))


if __name__ == '__main__':
    main()
