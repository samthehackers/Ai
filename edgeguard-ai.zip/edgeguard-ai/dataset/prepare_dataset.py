#!/usr/bin/env python3
"""Audit a Label Studio JSON export and convert it to a leakage-free YOLO dataset.

  python dataset/prepare_dataset.py --export export.json --audit-only
  python dataset/prepare_dataset.py --export export.json --images /path/to/images --out dataset/yolo

Nothing is invented: records whose image cannot be found are reported and excluded.
Label Studio stores uploads as '<8hex>-<original name>'; both forms are resolved.
"""
import argparse, collections, json, os, random, re, shutil, sys
import yaml

UUID_PREFIX = re.compile(r'^[0-9a-f]{8}-')
IMG_EXT = {'.jpg', '.jpeg', '.png', '.bmp', '.webp'}


def original_name(ref):
    return UUID_PREFIX.sub('', os.path.basename(ref))


def load_schema(path):
    with open(path) as f:
        y = yaml.safe_load(f)
    return y.get('normalize', {}), {int(k): v for k, v in y['classes'].items()}


def parse_export(export, schema_path):
    """Return (records, class_schema). Boxes are YOLO-normalised (cls, xc, yc, w, h) in [0,1]."""
    norm, names = load_schema(schema_path)
    name2id = {v['name']: k for k, v in names.items()}
    recs = []
    for t in export:
        ref = (t.get('data') or {}).get('image', '')
        r = dict(task_id=t.get('id'), ref=ref, orig=original_name(ref), status='valid', boxes=[], w=None, h=None,
                 issues=[], updated=t.get('updated_at'))
        anns = t.get('annotations') or []
        good = [a for a in anns if not a.get('was_cancelled')]
        if not anns:
            r['status'] = 'no_annotation'
        elif not good:
            r['status'] = 'cancelled'
        else:
            a = max(good, key=lambda a: a.get('updated_at') or '')
            for res in a.get('result', []):
                v = res.get('value', {})
                labs = v.get('rectanglelabels')
                if res.get('type') != 'rectanglelabels' or not labs:
                    r['issues'].append('non_rectangle_result'); continue
                lab = norm.get(labs[0], labs[0])
                if lab not in name2id:
                    r['issues'].append(f'unknown_label:{labs[0]}'); continue
                if v.get('rotation', 0):
                    r['issues'].append('rotated_box')
                r['w'], r['h'] = res.get('original_width'), res.get('original_height')
                x, y, w, h = (v[k] / 100.0 for k in ('x', 'y', 'width', 'height'))
                x0, y0, x1, y1 = max(0, x), max(0, y), min(1, x + w), min(1, y + h)
                if (x0, y0, x1, y1) != (x, y, x + w, y + h):
                    r['issues'].append('box_clipped')
                if x1 <= x0 or y1 <= y0:
                    r['issues'].append('degenerate_box'); continue
                r['boxes'].append((name2id[lab], (x0 + x1) / 2, (y0 + y1) / 2, x1 - x0, y1 - y0))
            if not r['boxes']:
                r['status'] = 'empty'   # valid annotation with no boxes (background image)
        recs.append(r)
    return recs, names


def parse_yolo_dir(root, schema_path):
    """Read a drop folder: <root>/images/*.jpg + <root>/labels/*.txt (YOLO format, ids as in classes.txt / classes.yaml).
    Images without a label file are UNLABELLED and excluded (never invented); an empty label file = background image."""
    norm, names = load_schema(schema_path)
    ct = os.path.join(root, 'classes.txt')
    if os.path.exists(ct):
        got = [norm.get(l.strip(), l.strip()) for l in open(ct) if l.strip()]
        want = [names[i]['name'] for i in range(len(names))]
        if got != want:
            raise SystemExit(f'classes.txt does not match configs/classes.yaml (ids would be wrong):\n{got}\n{want}')
    imgs, lbls = {}, {}
    for dp, _, fs in os.walk(os.path.join(root, 'images')):
        for f in fs:
            if os.path.splitext(f)[1].lower() in IMG_EXT: imgs[os.path.join(dp, f)] = f
    for dp, _, fs in os.walk(os.path.join(root, 'labels')):
        for f in fs:
            if f.endswith('.txt'):
                p = os.path.join(dp, f); lbls.setdefault(os.path.splitext(f)[0], p); lbls.setdefault(UUID_PREFIX.sub('', os.path.splitext(f)[0]), p)
    recs, paths, unlabelled = [], {}, []
    for i, (p, f) in enumerate(sorted(imgs.items(), key=lambda kv: kv[1])):
        stem = os.path.splitext(f)[0]; lp = lbls.get(stem) or lbls.get(UUID_PREFIX.sub('', stem))
        if not lp:
            unlabelled.append(f); continue
        r = dict(task_id=len(recs), ref=f, orig=original_name(f), status='valid', boxes=[], w=None, h=None, issues=[], updated=None)
        for line in open(lp).read().splitlines():
            t = line.split()
            if not t: continue
            try:
                c, x, y, w, h = int(t[0]), *map(float, t[1:5])
                assert 0 <= c < len(names) and 0 < w <= 1 and 0 < h <= 1 and 0 <= x <= 1 and 0 <= y <= 1 and len(t) == 5
            except (ValueError, AssertionError):
                r['issues'].append('bad_label_line'); continue
            r['boxes'].append((c, x, y, w, h))
        if not r['boxes']: r['status'] = 'empty'
        paths[len(recs)] = p; recs.append(r)
    return recs, names, paths, unlabelled


def iou(a, b):
    ax0, ay0, ax1, ay1 = a[1] - a[3] / 2, a[2] - a[4] / 2, a[1] + a[3] / 2, a[2] + a[4] / 2
    bx0, by0, bx1, by1 = b[1] - b[3] / 2, b[2] - b[4] / 2, b[1] + b[3] / 2, b[2] + b[4] / 2
    iw, ih = max(0, min(ax1, bx1) - max(ax0, bx0)), max(0, min(ay1, by1) - max(ay0, by0))
    i = iw * ih
    u = a[3] * a[4] + b[3] * b[4] - i
    return i / u if u > 0 else 0.0


def same_annotation(a, b, thr=0.7):
    if len(a) != len(b):
        return False
    used = set()
    for x in a:
        m = [(iou(x, y), j) for j, y in enumerate(b) if j not in used and y[0] == x[0]]
        if not m or max(m)[0] < thr:
            return False
        used.add(max(m)[1])
    return True


def dhash(path, size=8):
    import cv2
    im = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if im is None:
        return None
    s = cv2.resize(im, (size + 1, size), interpolation=cv2.INTER_AREA)
    bits = (s[:, 1:] > s[:, :-1]).flatten()
    return int(''.join('1' if b else '0' for b in bits), 2)


class UF:
    def __init__(s): s.p = {}
    def f(s, x):
        s.p.setdefault(x, x)
        while s.p[x] != x:
            s.p[x] = s.p[s.p[x]]; x = s.p[x]
        return x
    def u(s, a, b): s.p[s.f(a)] = s.f(b)


def build_groups(recs, paths=None, hash_thr=4):
    """Group records that must share a split: same original filename, plus near-identical images (dHash)."""
    uf = UF(); first = {}
    for i, r in enumerate(recs):
        uf.f(i)
        if r['orig'] in first:
            uf.u(i, first[r['orig']])
        else:
            first[r['orig']] = i
    near = 0
    if paths:
        hs = {}
        for i in range(len(recs)):
            p = paths.get(i)
            h = dhash(p) if p else None
            if h is not None:
                hs[i] = h
        items = list(hs.items())
        for a in range(len(items)):
            for b in range(a + 1, len(items)):
                if bin(items[a][1] ^ items[b][1]).count('1') <= hash_thr and uf.f(items[a][0]) != uf.f(items[b][0]):
                    uf.u(items[a][0], items[b][0]); near += 1
    groups = collections.defaultdict(list)
    for i in range(len(recs)):
        groups[uf.f(i)].append(i)
    return list(groups.values()), near


def dedupe(recs, groups, policy='quarantine'):
    """Same filename: drop exact label duplicates; files whose labels disagree are conflicts (policy decides)."""
    keep, dropped, conflicts = [], 0, []
    for g in groups:
        by_name = collections.defaultdict(list)
        for i in g:
            if recs[i]['status'] in ('valid', 'empty'):
                by_name[recs[i]['orig']].append(i)
        for o, idx in by_name.items():
            reps = []
            for i in idx:
                if not any(same_annotation(recs[i]['boxes'], recs[j]['boxes']) for j in reps):
                    reps.append(i)
            dropped += len(idx) - len(reps)
            if len(reps) > 1:
                conflicts.append(o)
                if policy == 'quarantine':
                    continue
                reps = [max(reps, key=lambda i: recs[i]['updated'] or '')]
            keep.extend(reps)
    return sorted(keep), dropped, conflicts


def split_groups(recs, groups, kept, ratios=(0.7, 0.15, 0.15), seed=42):
    kset = set(kept)
    gs = [[i for i in g if i in kset] for g in groups]
    gs = [g for g in gs if g]
    random.Random(seed).shuffle(gs)
    cnt = lambda g: collections.Counter(b[0] for i in g for b in recs[i]['boxes'])
    tot = collections.Counter()
    for g in gs:
        tot.update(cnt(g))
    n_tot = sum(len(g) for g in gs)
    gs.sort(key=lambda g: min([tot[c] for c in cnt(g)] or [10 ** 9]))   # rarest classes placed first
    cur = [collections.Counter() for _ in ratios]; size = [0] * len(ratios); out = [[] for _ in ratios]
    for g in gs:
        c = cnt(g); nb = max(sum(c.values()), 1)
        best, bs = 0, -1e18
        for s, rt in enumerate(ratios):
            sc = (rt * n_tot - size[s]) / max(rt * n_tot, 1)
            sc += sum((rt * tot[k] - cur[s][k]) / max(rt * tot[k], 1e-9) * v / nb for k, v in c.items())
            if sc > bs:
                best, bs = s, sc
        out[best].extend(g); cur[best].update(c); size[best] += len(g)
    return dict(zip(('train', 'val', 'test'), out))


def make_audit(recs, names, groups, kept, dropped, conflicts, split=None, extra=None):
    st = collections.Counter(r['status'] for r in recs)
    valid = [r for r in recs if r['status'] in ('valid', 'empty')]
    per_raw = collections.Counter(names[b[0]]['name'] for r in valid for b in r['boxes'])
    per_kept = collections.Counter(names[b[0]]['name'] for i in kept for b in recs[i]['boxes'])
    issues = collections.Counter(x.split(':')[0] for r in recs for x in r['issues'])
    tiny = sum(1 for r in valid for b in r['boxes'] if b[3] * b[4] < 0.005)
    portrait = sum(1 for r in recs if r['w'] and r['h'] and r['h'] > r['w'])
    land = sum(1 for r in recs if r['w'] and r['h'] and r['w'] >= r['h'])
    co = collections.Counter()
    for i in kept:
        ks = [names[b[0]] for b in recs[i]['boxes']]
        co[('risk' in {k['kind'] for k in ks}, 'hazard' in {k['kind'] for k in ks},
            any(k.get('role') == 'toddler' for k in ks))] += 1
    a = dict(tasks=len(recs), status=dict(st), unique_original_files=len({r['orig'] for r in recs}),
             duplicate_name_groups=sum(1 for g in groups if len(g) > 1), same_name_conflicts=len(conflicts),
             exact_duplicates_dropped=dropped, images_kept=len(kept), boxes_per_class_valid_raw=dict(per_raw),
             boxes_per_class_after_dedupe=dict(per_kept), box_issues=dict(issues), tiny_boxes_lt_0p5pct_area=tiny,
             portrait=portrait, landscape=land,
             cooccurrence_has_risk_has_hazard_has_toddler={str(k): v for k, v in co.items()})
    if split:
        a['split_images'] = {k: len(v) for k, v in split.items()}
        a['split_boxes_per_class'] = {k: dict(collections.Counter(names[b[0]]['name'] for i in v for b in recs[i]['boxes']))
                                      for k, v in split.items()}
    if extra:
        a.update(extra)
    return a


def write_report(a, path):
    L = ['# Dataset audit report', '', 'Generated by `dataset/prepare_dataset.py`. All numbers are computed from the export.', '',
         '## Records', f"- Tasks in export: **{a['tasks']}**", f"- Status: {a['status']}",
         f"- Unique original filenames: **{a['unique_original_files']}** (the same photo was uploaded several times)",
         f"- Filename-duplicate groups: {a['duplicate_name_groups']}; exact duplicate annotations dropped: {a['exact_duplicates_dropped']}",
         f"- Same filename but **conflicting** labels: {a['same_name_conflicts']} (see `--conflict-policy`)",
         f"- Unique images kept: **{a['images_kept']}**", '',
         '## Valid boxes per class (after `knive`->`knife` normalisation)', '', '| Class | Raw valid boxes | After dedupe |', '|---|---|---|']
    for k in sorted(a['boxes_per_class_valid_raw']):
        L.append(f"| {k} | {a['boxes_per_class_valid_raw'][k]} | {a['boxes_per_class_after_dedupe'].get(k, 0)} |")
    L += ['', '## Quality', f"- Box issues: {a['box_issues'] or 'none'}",
          f"- Tiny boxes (<0.5% of image area): {a['tiny_boxes_lt_0p5pct_area']} (flagged, not removed)",
          f"- Orientation: {a['portrait']} portrait / {a['landscape']} landscape", '',
          '## Approach A vs B evidence', '',
          'Counts of kept images by `(has risk-class box, has separate hazard-object box, has toddler-object box)`:', '',
          f"`{a['cooccurrence_has_risk_has_hazard_has_toddler']}`", '']
    if 'split_images' in a:
        L += ['## Split (group-aware: duplicates never straddle splits)', f"- Images: {a['split_images']}", '']
        L += [f"- {s}: {d}" for s, d in a['split_boxes_per_class'].items()] + ['']
    for k in ('unlabelled_images_excluded', 'missing_images', 'size_mismatch', 'near_duplicate_merges'):
        if k in a:
            L.append(f"- **{k}**: {a[k]}")
    with open(path, 'w') as f:
        f.write('\n'.join(L) + '\n')


def index_images(root):
    idx = {}
    for dp, _, fs in os.walk(root):
        for f in fs:
            if os.path.splitext(f)[1].lower() in IMG_EXT:
                p = os.path.join(dp, f)
                idx.setdefault(f, p); idx.setdefault(original_name(f), p)
    return idx


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--export'); ap.add_argument('--images'); ap.add_argument('--yolo-dir', help='drop folder with images/ and labels/ (YOLO txt) instead of a Label Studio export'); ap.add_argument('--out', default='dataset/yolo')
    ap.add_argument('--schema', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'configs', 'classes.yaml'))
    ap.add_argument('--audit-only', action='store_true'); ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--conflict-policy', choices=['quarantine', 'keep-latest'], default='quarantine')
    ap.add_argument('--hash-threshold', type=int, default=4)
    ap.add_argument('--oversample-rare', type=int, default=0, help='repeat (max x4) train images containing classes with < N train boxes')
    ap.add_argument('--report-dir', default=os.path.dirname(os.path.abspath(__file__)))
    a = ap.parse_args(argv)
    unlabelled = []
    if a.yolo_dir:
        recs, names, paths, unlabelled = parse_yolo_dir(a.yolo_dir, a.schema); idx = {'_': 1} if paths else {}
    elif a.export:
        recs, names = parse_export(json.load(open(a.export)), a.schema)
        idx = index_images(a.images) if a.images else {}
        paths = {i: idx.get(os.path.basename(r['ref'])) or idx.get(r['orig']) for i, r in enumerate(recs)} if idx else {}
    else:
        ap.error('give --yolo-dir or --export')
    groups, near = build_groups(recs, paths if idx else None, a.hash_threshold)
    keep, dropped, conflicts = dedupe(recs, groups, a.conflict_policy)
    extra = {'unlabelled_images_excluded': len(unlabelled)} if a.yolo_dir else {}
    os.makedirs(a.report_dir, exist_ok=True)
    if unlabelled: open(os.path.join(a.report_dir, 'unlabelled_images.txt'), 'w').write('\n'.join(unlabelled) + '\n')
    if idx:
        missing = [i for i in keep if not paths.get(i)]
        extra['missing_images'] = f"{len(missing)} of {len(keep)} kept records have no image file (excluded)"
        keep = [i for i in keep if paths.get(i)]
        extra['near_duplicate_merges'] = near
        from PIL import Image
        bad = 0
        for i in list(keep):
            try:
                w, h = Image.open(paths[i]).size
                if recs[i]['w'] and (w, h) not in ((recs[i]['w'], recs[i]['h']), (recs[i]['h'], recs[i]['w'])):
                    bad += 1
            except Exception:
                bad += 1; keep.remove(i)
        extra['size_mismatch'] = f"{bad} images unreadable or with size different from the annotation size"
    else:
        extra['missing_images'] = 'NOT CHECKED: no --images directory supplied. Training data cannot be built without the image files.'
    split = split_groups(recs, groups, keep, seed=a.seed) if idx else None
    audit = make_audit(recs, names, groups, keep, dropped, conflicts, split, extra)
    os.makedirs(a.report_dir, exist_ok=True)
    json.dump(audit, open(os.path.join(a.report_dir, 'audit.json'), 'w'), indent=2)
    json.dump(conflicts, open(os.path.join(a.report_dir, 'label_conflicts.json'), 'w'), indent=1)
    write_report(audit, os.path.join(a.report_dir, 'audit_report.md'))
    print(json.dumps({k: audit[k] for k in ('tasks', 'status', 'unique_original_files', 'same_name_conflicts', 'images_kept')}, indent=1))
    if a.audit_only:
        return 0
    if not idx:
        print('ERROR: --images is required to build the dataset', file=sys.stderr); return 2
    out = os.path.abspath(a.out)
    stems = {}
    for s, ids in split.items():
        os.makedirs(f'{out}/images/{s}', exist_ok=True); os.makedirs(f'{out}/labels/{s}', exist_ok=True)
        for i in ids:
            r = recs[i]; stem = f"{r['task_id']}_{os.path.splitext(r['orig'])[0]}"
            dst = f'{out}/images/{s}/{stem}{os.path.splitext(paths[i])[1]}'
            shutil.copy2(paths[i], dst); stems[i] = dst
            with open(f'{out}/labels/{s}/{stem}.txt', 'w') as f:
                for c, x, y, w, h in r['boxes']:
                    f.write(f'{c} {x:.6f} {y:.6f} {w:.6f} {h:.6f}\n')
    train_ref = 'images/train'
    if a.oversample_rare:
        cnt = collections.Counter(b[0] for i in split['train'] for b in recs[i]['boxes'])
        lines = []
        for i in split['train']:
            rare = [cnt[c] for c in {b[0] for b in recs[i]['boxes']} if cnt[c] < a.oversample_rare]
            rep = min(4, 1 + max(a.oversample_rare // max(n, 1) for n in rare) - 1) if rare else 1
            lines += [stems[i]] * max(rep, 1)
        open(f'{out}/train_balanced.txt', 'w').write('\n'.join(lines) + '\n'); train_ref = 'train_balanced.txt'
    yaml.safe_dump({'path': out, 'train': train_ref, 'val': 'images/val', 'test': 'images/test',
                    'names': {k: v['name'] for k, v in names.items()}}, open(f'{out}/data.yaml', 'w'), sort_keys=False)
    print('dataset written to', out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
