# Technical feasibility report (computed from the supplied Label Studio export)

## Blocking finding
The export references `/data/upload/2/<8hex>-<name>.jpg` but **the image files were not supplied**. No model can be trained or evaluated, and no real detection accuracy or Raspberry Pi benchmark exists yet. Everything in this project that does not need the images is built and tested; everything that does is implemented but **pending**.

## Dataset audit (`dataset/audit_report.md`, `dataset/audit.json`)
| Item | Value |
|---|---|
| Tasks (one annotation each) | 1,930 (1,831 valid with boxes, 12 valid but empty, 87 cancelled) |
| Unique original filenames | 1,361 (510 filenames were uploaded 2-4 times) |
| Exact duplicate annotations dropped | 257 |
| **Same file, conflicting labels** | **275 filenames** (quarantined by default) |
| Images kept after dedupe/quarantine | 1,025 |
| Box issues | 32 clipped to image bounds, 1 rotated box, 8 tiny boxes (<0.5% area, flagged) |
| Orientation | 1,572 portrait / 259 landscape |

Label conflicts among duplicate uploads (275): **144 disagree on the risk level** (e.g. LOW vs NO vs HIGH on the same photo), 46 differ in class but not risk level, 85 have the same classes with different boxes (IoU 0.3-0.7). The risk label, the safety-critical one, is therefore partly inconsistent. A human must adjudicate these before the risk classes can be trusted (`dataset/label_conflicts.json` lists them; `--conflict-policy keep-latest` is available but not recommended without review).

Valid boxes per class after normalisation and dedupe (the raw counts are in the audit report):

| Class | Boxes |
|---|---|
| TODDLER NEAR KNIFE (HIGH) / (LOW) / (NO) | 241 / 114 / 78 |
| TODDLER NEAR ELECTRIC IRON (HIGH) / (LOW) / (NO) | 211 / 108 / 139 |
| toddlers / adult female / adult male | 72 / 38 / 23 |
| electric iron / knife | 2 / 5 |

`knive` -> `knife` is the only label normalisation (documented in `configs/classes.yaml`). Class imbalance is handled by the group-aware stratified split, optional oversampling (`--oversample-rare`) and augmentation. `knife` (5) and `electric iron` (2) are too rare to learn or evaluate; per-class metrics for them will be unreliable and must be reported as such.

## Approach A vs B
- **A. Direct detection of the six risk classes.** 885 kept images contain a risk-class box and nothing else. This is how the data was labelled.
- **B. Detect toddler + hazard separately, then compute proximity.** Separate hazard-object boxes exist in only 4 kept images (7 boxes), and a toddler-object box co-occurs with a risk class in 1 image. B has no training data for its hazard detectors and cannot be trained or evaluated from this dataset.

**Decision: A.** The risk engine (`risk_engine.py`) adds persistence, uncertainty handling and an optional image-plane proximity hint, and does not pretend to measure physical distance. B should be revisited only after labelling standalone knives, irons and toddlers.

## Architecture choice
Not yet decided empirically. Candidates: YOLOv8n/YOLO11n (and `s` if the nano is too weak) exported to ONNX Runtime CPU. Choose by test mAP/F1 (`evaluate.py`) plus latency and RSS on a real Pi 5 (`benchmark.py`). The runtime is ONNX Runtime, which needs no PyTorch on the Pi.
