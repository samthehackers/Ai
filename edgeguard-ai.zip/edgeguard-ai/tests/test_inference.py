import os
import numpy as np
from conftest import make_fixture_onnx
from inference import Detector, decode, letterbox, nms

CFG = dict(path='fixture.onnx', classes_file='configs/classes.yaml', imgsz=640, conf_floor=0.15, nms_iou=0.5, threads=1)
BASE = os.path.join(os.path.dirname(__file__), '..')


def test_letterbox_geometry():
    img = np.zeros((480, 640, 3), np.uint8)
    out, r, l, t = letterbox(img, 640)
    assert out.shape == (640, 640, 3) and r == 1.0 and l == 0 and t == 80


def test_nms_suppresses_overlap():
    b = np.array([[0, 0, 100, 100], [5, 5, 105, 105], [300, 300, 400, 400]], float)
    assert nms(b, np.array([.9, .8, .7]), .5) == [0, 2]


def test_decode_maps_back_to_original_pixels():
    out = np.zeros((1, 15, 5), np.float32); out[0, :4, 0] = (320, 320, 200, 200); out[0, 4 + 3, 0] = .9
    r = decode(out, 11, 1.0, 0, 80, (480, 640), .15, .5)
    assert len(r) == 1 and r[0][0] == 3 and np.allclose(r[0][2:], (220, 140, 420, 340), atol=1e-3)


def test_decode_rejects_wrong_class_count():
    import pytest
    with pytest.raises(ValueError):
        decode(np.zeros((1, 20, 5), np.float32), 11, 1, 0, 0, (10, 10))


def test_detector_with_fixture_model(tmp_path):
    p = tmp_path / 'm.onnx'; make_fixture_onnx(str(p), [(3, .9, 320, 320, 200, 200), (6, .05, 100, 100, 50, 50)])
    d = Detector({**CFG, 'path': str(p)}, BASE)
    assert d.ready
    dets = d.predict(np.zeros((480, 640, 3), np.uint8))
    assert [x.name for x in dets] == ['TODDLER NEAR KNIFE (HIGH RISK)'] and abs(dets[0].conf - .9) < 1e-5   # .05 < conf_floor, dropped
    assert d.last_ms > 0


def test_missing_model_is_reported_not_crashing():
    d = Detector({**CFG, 'path': 'nope.onnx'}, BASE)
    assert not d.ready and 'not found' in d.error


def test_model_class_mismatch_is_reported(tmp_path):
    p = tmp_path / 'm.onnx'; make_fixture_onnx(str(p), [], nc=7)
    d = Detector({**CFG, 'path': str(p)}, BASE)
    assert not d.ready and 'does not match' in d.error


def test_class_schema_validation(tmp_path):
    import pytest
    from inference import load_classes
    cl = load_classes(os.path.join(BASE, 'configs', 'classes.yaml'))
    assert [cl[i]['level'] for i in range(6)] == ['HIGH', 'LOW', 'NO', 'HIGH', 'LOW', 'NO']
    bad = tmp_path / 'c.yaml'; bad.write_text('classes:\n  0: {name: x, kind: risk, hazard: knife, level: NO}\n')
    with pytest.raises(ValueError):
        load_classes(str(bad))
