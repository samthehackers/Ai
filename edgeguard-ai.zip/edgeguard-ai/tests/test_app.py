import os, time, yaml
import pytest
from conftest import make_fixture_onnx, make_video
import app as appmod

BASE = os.path.join(os.path.dirname(__file__), '..')


def write_cfg(tmp, model_dets, video=True, token=None, mllm_mode='off', mllm_url=''):
    cfg = yaml.safe_load(open(os.path.join(BASE, 'config.yaml')))
    m = tmp / 'm.onnx'
    if model_dets is not None: make_fixture_onnx(str(m), model_dets)
    v = tmp / 'v.mp4'
    if video: make_video(str(v), frames=60, fps=60)
    cfg['model'].update(path=str(m), threads=1); cfg['camera'].update(source=str(v) if video else str(tmp / 'none.mp4?x'), fps=60, loop=True, reconnect_delay_s=0.1, max_reconnect_delay_s=0.2)
    cfg['inference']['every_n_frames'] = 1
    cfg['inbox'].update(dir=str(tmp / 'inbox'), out_dir=str(tmp / 'outbox'), poll_s=0.2)
    cfg['mllm'].update(mode=mllm_mode, offline=dict(base_url=mllm_url, model='local-vlm' if mllm_url else '', timeout_s=5), min_interval_s=0)
    cfg['mllm']['online']['api_key_env'] = 'UNSET_OR_KEY'
    cfg['alerts'].update(audio=False, snapshot_dir=str(tmp / 'snaps'), db_path=str(tmp / 'ev.db'))
    cfg['server']['auth_token_env'] = 'EG_TEST_TOKEN' if token else 'UNSET_X'
    p = tmp / 'config.yaml'; p.write_text(yaml.safe_dump(cfg)); return str(p)


def wait(cond, t=8):
    end = time.time() + t
    while time.time() < end:
        r = cond()
        if r: return r
        time.sleep(0.1)
    return None


@pytest.fixture
def client_factory(tmp_path, monkeypatch):
    apps = []
    def f(dets, **kw):
        if kw.get('token'): monkeypatch.setenv('EG_TEST_TOKEN', kw['token'])
        a = appmod.create_app(write_cfg(tmp_path, dets, **{k: v for k, v in kw.items()}))
        apps.append(a); return a, a.test_client()
    yield f
    for a in apps: a.pipeline.stop()


def test_high_risk_end_to_end(client_factory):
    a, c = client_factory([(3, .9, 320, 320, 200, 200)])
    s = wait(lambda: (lambda j: j if j['system_state'] == 'HIGH' else None)(c.get('/api/status').get_json()))
    assert s and s['risk']['hazard'] == 'knife' and s['model']['ready'] and s['camera']['status'] == 'ok'
    ev = wait(lambda: c.get('/api/events').get_json())
    assert ev and ev[0]['level'] == 'HIGH' and os.path.exists(os.path.join(os.path.dirname(a.pipeline.store.db.cursor().execute('PRAGMA database_list').fetchone()[2]), 'snaps'))
    assert len(c.get('/api/events').get_json()) == 1                     # cooldown: continuous event alerts once


def test_nothing_detected_is_no_risk(client_factory):
    a, c = client_factory([])
    assert wait(lambda: c.get('/api/status').get_json()['system_state'] == 'NO_RISK')


def test_missing_model_never_reads_as_safe(client_factory):
    a, c = client_factory(None)
    s = wait(lambda: (lambda j: j if j['system_state'] == 'MODEL_UNAVAILABLE' else None)(c.get('/api/status').get_json()))
    assert s and not s['model']['ready'] and 'not found' in s['model']['error']


def test_camera_failure_never_reads_as_safe(client_factory):
    a, c = client_factory([], video=False)
    assert wait(lambda: c.get('/api/status').get_json()['system_state'] == 'CAMERA_UNAVAILABLE')


def test_video_feed_streams_jpeg(client_factory):
    a, c = client_factory([(3, .9, 320, 320, 200, 200)])
    wait(lambda: a.pipeline.jpeg)
    r = c.get('/video_feed', buffered=False); chunk = next(iter(r.response))
    assert r.mimetype == 'multipart/x-mixed-replace' and b'\xff\xd8' in chunk
    r.close()


def test_config_validation_and_persistence(client_factory, tmp_path):
    a, c = client_factory([])
    assert c.post('/api/config', json={'high_conf': 0.6}).get_json()['high_conf'] == 0.6
    assert c.post('/api/config', json={'high_conf': 5}).status_code == 400
    assert c.post('/api/config', json={'nope': 1}).status_code == 400
    assert c.post('/api/config', json={'uncertain_conf': 0.9}).status_code == 400
    assert os.path.exists(tmp_path / 'logs' / 'runtime_overrides.json')


def test_config_requires_token_when_set(client_factory):
    a, c = client_factory([], token='s3cret')
    assert c.post('/api/config', json={'high_conf': .6}).status_code == 401
    assert c.post('/api/config', json={'high_conf': .6}, headers={'X-Auth-Token': 'wrong'}).status_code == 401
    assert c.post('/api/config', json={'high_conf': .6}, headers={'X-Auth-Token': 's3cret'}).status_code == 200


def test_dashboard_and_health(client_factory):
    a, c = client_factory([])
    assert b'EDGEGUARD AI' in c.get('/').data and c.get('/health').get_json()['ok']


def png_bytes():
    import cv2, numpy as np
    return cv2.imencode('.png', (np.random.RandomState(2).rand(120, 160, 3) * 255).astype('uint8'))[1].tobytes()


def test_inbox_folder_drop_processes_images(client_factory, tmp_path):
    import cv2, numpy as np, json
    a, c = client_factory([(3, .9, 320, 320, 200, 200)])
    inbox = tmp_path / 'inbox'
    cv2.imwrite(str(inbox / 'a.jpg'), np.zeros((300, 400, 3), np.uint8))
    (inbox / 'broken.jpg').write_bytes(b'not an image')
    r = wait(lambda: (lambda j: j if len(j['results']) >= 1 and j['status']['errors'] >= 1 else None)(c.get('/api/inbox').get_json()), 10)
    assert r and r['results'][0]['level'] == 'HIGH' and r['results'][0]['hazard'] == 'knife' and r['results'][0]['single_image']
    assert r['results'][0]['mllm']['status'] == 'disabled'
    assert os.listdir(inbox / 'processed') and os.listdir(inbox / 'failed')           # processed and failed files are moved aside
    rid = r['results'][0]['id']; assert c.get(f'/outbox/{rid}.jpg').data[:2] == b'\xff\xd8' and c.get('/outbox/x.txt').status_code == 404


def test_upload_endpoint_and_validation(client_factory):
    import io
    a, c = client_factory([(3, .9, 320, 320, 200, 200)])
    ok = c.post('/api/inbox/upload', data={'file': (io.BytesIO(png_bytes()), 'kid.png')}, content_type='multipart/form-data')
    assert ok.status_code == 200 and ok.get_json()['saved']
    bad = c.post('/api/inbox/upload', data={'file': (io.BytesIO(b'xx'), 'evil.exe')}, content_type='multipart/form-data')
    fake = c.post('/api/inbox/upload', data={'file': (io.BytesIO(b'xx'), 'fake.png')}, content_type='multipart/form-data')
    assert bad.status_code == 400 and fake.status_code == 400
    assert wait(lambda: c.get('/api/inbox').get_json()['results'], 10)


def test_inbox_waits_when_model_missing(client_factory, tmp_path):
    import cv2, numpy as np
    a, c = client_factory(None)
    cv2.imwrite(str(tmp_path / 'inbox' / 'a.jpg'), np.zeros((50, 50, 3), np.uint8))
    assert wait(lambda: 'model unavailable' in (c.get('/api/inbox').get_json()['status']['note'] or ''), 10)
    assert os.path.exists(tmp_path / 'inbox' / 'a.jpg')                                   # kept, not lost or faked


def test_mllm_is_advisory_and_never_lowers_risk(client_factory, llm):
    fake = llm(reply='{"danger":"NONE","toddler_present":false,"hazards":[],"explanation":"nothing dangerous"}')
    a, c = client_factory([(3, .9, 320, 320, 200, 200)], mllm_mode='offline', mllm_url=fake.url)
    ev = wait(lambda: [e for e in c.get('/api/events').get_json() if e['mllm']], 10)
    assert ev and 'NONE' in ev[0]['mllm']
    s = c.get('/api/status').get_json()
    assert s['system_state'] == 'HIGH' and ev[0]['level'] == 'HIGH'                       # LLM said NONE; detector alert stands
    assert s['mllm']['active_backend'] == 'offline'


def test_detection_works_with_mllm_down(client_factory):
    a, c = client_factory([(3, .9, 320, 320, 200, 200)], mllm_mode='auto', mllm_url='http://127.0.0.1:9/v1')
    assert wait(lambda: c.get('/api/status').get_json()['system_state'] == 'HIGH')
    ev = wait(lambda: c.get('/api/events').get_json(), 8)
    assert ev and ev[0]['level'] == 'HIGH' and c.get('/api/status').get_json()['mllm']['active_backend'] is None
