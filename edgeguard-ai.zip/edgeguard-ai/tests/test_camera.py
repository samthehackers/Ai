import time
from camera import Camera
from conftest import make_video


def wait(cond, t=5):
    end = time.time() + t
    while time.time() < end:
        if cond(): return True
        time.sleep(0.05)
    return False


def test_video_file_source(tmp_path):
    v = str(tmp_path / 'v.mp4'); make_video(v, frames=20, fps=100)
    c = Camera(dict(source=v, width=640, height=480, fps=100)).start()
    assert wait(lambda: c.read()[0] is not None)
    assert wait(lambda: c.status == 'ended'); c.stop()
    f, age, seq = c.read(); assert f.shape == (480, 640, 3) and seq > 5


def test_bad_source_reconnects_and_reports(tmp_path):
    c = Camera(dict(source=str(tmp_path / 'missing.mp4') + '?x', width=640, height=480, fps=10, reconnect_delay_s=0.1, max_reconnect_delay_s=0.2)).start()
    assert wait(lambda: c.reconnects >= 2) and c.status == 'reconnecting' and 'cannot open' in c.error
    c.stop()
