import time
import numpy as np
from conftest import free_port_url
from mllm import MLLM, parse_reply

IMG = np.zeros((120, 160, 3), np.uint8)


def cfg(mode='auto', online=None, offline=None, **kw):
    return dict(mode=mode, use_for=['events', 'inbox'], max_image_px=256, min_interval_s=0.5,
                online=dict(base_url=(online or free_port_url()), model='vision-x', api_key_env='EG_OR_KEY', timeout_s=5),
                offline=dict(base_url=(offline or free_port_url()), model='local-vlm', timeout_s=5), **kw)


def run_job(m, kind='inbox'):
    out = []
    assert m.submit(IMG, 'ctx', out.append, kind=kind)
    end = time.time() + 8
    while not out and time.time() < end: time.sleep(0.05)
    m.stop(); return out[0]


def test_parse_reply_variants():
    assert parse_reply('```json\n{"danger":"high","explanation":"x"}\n```')['danger'] == 'HIGH'
    assert parse_reply('I think it is dangerous!')['danger'] == 'UNSURE'
    assert parse_reply('{"danger":"MAYBE"}')['danger'] == 'UNSURE'
    assert parse_reply(None)['danger'] == 'UNSURE'


def test_routing_rules(llm, monkeypatch):
    monkeypatch.delenv('EG_OR_KEY', raising=False)
    assert MLLM(cfg('off')).route() is None
    assert MLLM(cfg('auto')).route() is None                       # nothing configured/reachable -> detector only
    on, off = llm(), llm()
    assert MLLM(cfg('online', on.url)).route() is None             # no key -> never goes online
    monkeypatch.setenv('EG_OR_KEY', 'k')
    assert MLLM(cfg('auto', on.url, off.url)).route().name == 'online'
    assert MLLM(cfg('auto', free_port_url(), off.url)).route().name == 'offline'   # online unreachable -> offline
    assert MLLM(cfg('offline', on.url, off.url)).route().name == 'offline'


def test_online_call_is_authenticated_and_advisory(llm, monkeypatch):
    monkeypatch.setenv('EG_OR_KEY', 'sekret'); on = llm()
    r = run_job(MLLM(cfg('online', on.url)).start())
    assert r['ok'] and r['backend'] == 'online' and r['danger'] == 'HIGH' and r['advisory'] is True
    assert on.last_auth == 'Bearer sekret' and on.last_body['model'] == 'vision-x'
    assert on.last_body['messages'][0]['content'][1]['image_url']['url'].startswith('data:image/jpeg;base64,')


def test_offline_needs_no_key(llm, monkeypatch):
    monkeypatch.delenv('EG_OR_KEY', raising=False); off = llm()
    r = run_job(MLLM(cfg('auto', None, off.url)).start())
    assert r['ok'] and r['backend'] == 'offline' and off.last_auth is None


def test_auto_falls_back_when_online_errors(llm, monkeypatch):
    monkeypatch.setenv('EG_OR_KEY', 'k'); on, off = llm(status=500), llm()
    r = run_job(MLLM(cfg('auto', on.url, off.url)).start())
    assert r['ok'] and r['backend'] == 'offline' and on.calls == 1


def test_failure_is_reported_not_raised(llm, monkeypatch):
    monkeypatch.delenv('EG_OR_KEY', raising=False); off = llm(status=500)
    r = run_job(MLLM(cfg('offline', None, off.url)).start())
    assert r['ok'] is False and 'offline' in r['error']


def test_submit_never_blocks_and_is_rate_limited(llm, monkeypatch):
    monkeypatch.delenv('EG_OR_KEY', raising=False); off = llm(delay=1.0)
    m = MLLM(cfg('offline', None, off.url)).start()
    t = time.time(); ok1 = m.submit(IMG, '', lambda r: None, 'event'); ok2 = m.submit(IMG, '', lambda r: None, 'event')
    assert time.time() - t < 0.3 and ok1 and not ok2             # slow server does not block; 2nd event within interval dropped
    m.stop()


def test_disabled_modes_submit_nothing():
    m = MLLM(cfg('off')); assert m.submit(IMG, '', lambda r: None, 'inbox') is False
