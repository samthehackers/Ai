"""Alerts: cooldown-limited audible/visual events, SQLite event log, optional Telegram (never blocks detection)."""
import json, logging, os, shutil, sqlite3, subprocess, threading, time, urllib.request, uuid, wave, struct, math
from datetime import datetime, timezone

log = logging.getLogger('edgeguard.alerts')


class EventStore:
    def __init__(self, path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False); self.lock = threading.Lock()
        with self.lock:
            self.db.execute('''CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, level TEXT,
                hazard TEXT, det_conf REAL, risk_conf REAL, proximity REAL, message TEXT, snapshot TEXT, telegram TEXT)''')
            if 'mllm' not in [r[1] for r in self.db.execute('PRAGMA table_info(events)')]:
                self.db.execute('ALTER TABLE events ADD COLUMN mllm TEXT')
            self.db.commit()

    def set_mllm(self, eid, res):
        with self.lock:
            self.db.execute('UPDATE events SET mllm=? WHERE id=?', (json.dumps(res), eid)); self.db.commit()

    def add(self, level, hazard, det_conf, risk_conf, proximity, message, snapshot=None, telegram='disabled'):
        with self.lock:
            cur = self.db.execute('INSERT INTO events(ts,level,hazard,det_conf,risk_conf,proximity,message,snapshot,telegram) VALUES(?,?,?,?,?,?,?,?,?)',
                                  (datetime.now(timezone.utc).isoformat(timespec='seconds'), level, hazard, det_conf, risk_conf,
                                   proximity, message, snapshot, telegram))
            self.db.commit(); return cur.lastrowid

    def set_telegram(self, eid, status):
        with self.lock:
            self.db.execute('UPDATE events SET telegram=? WHERE id=?', (status, eid)); self.db.commit()

    def recent(self, n=50):
        with self.lock:
            cur = self.db.execute('SELECT id,ts,level,hazard,det_conf,risk_conf,proximity,message,snapshot,telegram,mllm FROM events ORDER BY id DESC LIMIT ?', (n,))
            cols = [c[0] for c in cur.description]; return [dict(zip(cols, r)) for r in cur.fetchall()]

    def counts(self):
        with self.lock:
            return dict(self.db.execute('SELECT level, COUNT(*) FROM events GROUP BY level').fetchall())

    def close(self):
        with self.lock:
            self.db.close()


def make_beep(path, freq=880, dur=0.35, rate=22050, repeats=3):
    if os.path.exists(path):
        return
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with wave.open(path, 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        for _ in range(repeats):
            for i in range(int(rate * dur)):
                w.writeframes(struct.pack('<h', int(12000 * math.sin(2 * math.pi * freq * i / rate))))
            w.writeframes(b'\x00\x00' * int(rate * 0.12))


class Telegram:
    def __init__(self, cfg):
        self.enabled = bool(cfg.get('enabled'))
        self.token = os.environ.get(cfg.get('token_env', ''), ''); self.chat = os.environ.get(cfg.get('chat_id_env', ''), '')
        self.send_snapshot = cfg.get('send_snapshot', True)
        if self.enabled and not (self.token and self.chat):
            log.warning('Telegram enabled but token/chat id env vars are empty; notifications disabled')
            self.enabled = False

    def send(self, text, snapshot=None):
        """Blocking; call from a worker thread. Returns 'sent' or an error string."""
        try:
            if snapshot and self.send_snapshot and os.path.exists(snapshot):
                b = uuid.uuid4().hex; data = open(snapshot, 'rb').read()
                body = (f'--{b}\r\nContent-Disposition: form-data; name="chat_id"\r\n\r\n{self.chat}\r\n'
                        f'--{b}\r\nContent-Disposition: form-data; name="caption"\r\n\r\n{text}\r\n'
                        f'--{b}\r\nContent-Disposition: form-data; name="photo"; filename="s.jpg"\r\nContent-Type: image/jpeg\r\n\r\n').encode() + data + f'\r\n--{b}--\r\n'.encode()
                req = urllib.request.Request(f'https://api.telegram.org/bot{self.token}/sendPhoto', body, {'Content-Type': f'multipart/form-data; boundary={b}'})
            else:
                req = urllib.request.Request(f'https://api.telegram.org/bot{self.token}/sendMessage',
                                             json.dumps({'chat_id': self.chat, 'text': text}).encode(), {'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=8).read()
            return 'sent'
        except Exception as e:                                   # noqa: BLE001 - offline operation must continue
            return f'failed: {type(e).__name__}'


class AlertManager:
    def __init__(self, cfg, store, base_dir='.', notify=None):
        self.cfg, self.store, self.base = cfg, store, base_dir
        self.last = {}                      # level -> monotonic time of last fired alert
        self.snap_dir = os.path.join(base_dir, cfg['snapshot_dir']); os.makedirs(self.snap_dir, exist_ok=True)
        self.beep = os.path.join(base_dir, 'logs', 'beep.wav')
        self.tg = Telegram(cfg.get('telegram', {})); self.notify = notify
        self.audio_ok = bool(shutil.which('aplay') or shutil.which('paplay'))
        if cfg.get('audio') and not self.audio_ok:
            log.warning('no aplay/paplay found; audible alerts disabled (install alsa-utils)')
        if cfg.get('audio'):
            make_beep(self.beep)
        self.active = None                  # banner for the dashboard: {'level','ts'}
        self.test_hook = None

    def _cooldown(self, level):
        return self.cfg['cooldown_high_s'] if level == 'HIGH' else self.cfg['cooldown_low_s']

    def _play(self):
        for exe in ('aplay', 'paplay'):
            p = shutil.which(exe)
            if p:
                try:
                    subprocess.Popen([p, '-q', self.beep] if exe == 'aplay' else [p, self.beep],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                except OSError as e:
                    log.warning('audio failed: %s', e)
                return

    def handle(self, state, frame=None, now=None):
        """Fire an alert for HIGH/LOW (cooldown-limited). Returns event id or None."""
        level = state.level
        if level not in ('HIGH', 'LOW'):
            return None
        now = time.monotonic() if now is None else now
        if level in self.last and now - self.last[level] < self._cooldown(level):
            return None
        if level == 'LOW' and 'HIGH' in self.last and now - self.last['HIGH'] < self._cooldown('HIGH'):
            return None                     # a recent HIGH already covers this situation
        self.last[level] = now
        msg = f"{level} RISK: {state.hazard or 'hazard'} (det {state.detection_conf:.2f}, risk-class {state.risk_class_conf:.2f})"
        snap = None
        if frame is not None:
            import cv2
            snap = os.path.join(self.snap_dir, f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{level}.jpg")
            cv2.imwrite(snap, frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        eid = self.store.add(level, state.hazard, state.detection_conf, state.risk_class_conf, state.proximity_hint, msg,
                             os.path.relpath(snap, self.base) if snap else None, 'queued' if self.tg.enabled else 'disabled')
        log.warning(msg)
        if self.cfg.get('audio') and self.audio_ok:
            self._play()
        if self.tg.enabled:
            threading.Thread(target=lambda: self.store.set_telegram(eid, self.tg.send('EDGEGUARD AI: ' + msg, snap)), daemon=True).start()
        return eid
