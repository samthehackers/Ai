# Training drop folder

Drop your training pictures here:

    training_data/images/   <- the pictures (.jpg .jpeg .png)
    training_data/labels/   <- one YOLO .txt per picture (same name; Label Studio's 8-hex prefix is handled)
    training_data/classes.txt  <- optional; if present it must match the class order in configs/classes.yaml

Or drop a Label Studio JSON export in `training_data/` together with the pictures in `images/`.

Rules the pipeline enforces (nothing is invented):
- A picture with **no label file is excluded** (listed in `dataset/unlabelled_images.txt`). An **empty** label file = a picture with nothing dangerous in it (background).
- Class ids must follow `classes.txt` order (0..5 = toddler near iron/knife HIGH/LOW/NO, 6 adult female, 7 adult male, 8 electric iron, 9 knife, 10 toddlers).
- Copies of the same photo are grouped so they never land in both the training and test sets.

Then train and deploy with one command (on a GPU machine or Colab):

    pip install -r requirements-train.txt
    scripts/train_from_dropbox.sh
