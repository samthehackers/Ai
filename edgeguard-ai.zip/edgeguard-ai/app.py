#!/usr/bin/env python3
"""EDGEGUARD AI: local monitoring service (camera -> detector -> risk engine -> alerts -> web dashboard)."""
import argparse, collections, copy, hmac, json, logging, os, signal, threading, time
import psutil, yaml
from werkzeug.utils import secure_filename
from flask import Flask, Response, abort, jsonify, request, send_from_directory

from alerts import AlertManager, EventStore
from camera import Camera
from inference import Detector, draw, LEVEL_COLOR
from inbox import InboxWatcher, EXT
from mllm import MLLM
from risk_engine import RiskEngine, NO_RISK

log = logging.getLogger('edgeguard')
BASE = os.path.dirname(os.path.abspath(__file__))
TUNABLE = {'high_conf': (0.05, 0.99), 'low_conf': (0.05, 0.99), 'uncertain_conf': (0.01, 0.95), 'window': (2, 60),
           'high_hits': (1, 60), 'low_hits': (1, 60), 'uncertain_hits': (1, 60), 'clear_frames': (1, 300)}


def load_config(path):
    with open(path) as f:
        cfg = yaml.safe_load(f)
    ov = os.path.join(os.path.dirname(os.path.abspath(path)), 'logs', 'runtime_overrides.json')
    if os.path.exists(ov):
        try:
            cfg['risk'].update(json.load(open(ov)))
        except Exception as e:                                   # noqa: BLE001
            log.warning('ignoring bad overrides file: %s', e)
    return cfg


def pi_temp():
    try:
        return int(open('/sys/class/thermal/thermal_zone0/temp').read()) / 1000.0
    except OSError:
        return None


class Pipeline(threading.Thread):
    def __init__(self, cfg, base=BASE):
        super().__init__(name='pipeline', daemon=True)
        self.cfg, self.base = cfg, base
        self.detector = Detector(cfg['model'], base)
        self.engine = RiskEngine(self.detector.classes, cfg['risk'])
        self.store = EventStore(os.path.join(base, cfg['alerts']['db_path']))
        self.alerts = AlertManager(cfg['alerts'], self.store, base)
        self.camera = Camera(cfg['camera'])
        self.mllm = MLLM(cfg.get('mllm', {}))
        self.inbox = InboxWatcher(cfg.get('inbox', {}), base, self.detector, cfg['risk'], self.mllm)
        self.stop_evt = threading.Event(); self.lock = threading.Lock()
        self.jpeg = None; self.dets = []; self.state = None
        self.system_state = 'STARTING'; self.frames = 0; self.inferences = 0
        self.fps = 0.0; self.inf_ms = collections.deque(maxlen=30); self.class_counts = collections.Counter()
        self.t0 = time.time(); self.proc = psutil.Process()

    def stop(self):
        self.stop_evt.set(); self.camera.stop(); self.inbox.stop(); self.mllm.stop()
        self.join(timeout=3); self.store.close()

    def run(self):
        import cv2
        self.camera.start(); self.mllm.start(); self.inbox.start(); last_seq = -1; n = 0; tick = time.time(); k = 0
        while not self.stop_evt.is_set():
            frame, age, seq = self.camera.read()
            if frame is None or seq == last_seq:
                if frame is not None and age > 3.0 or frame is None:
                    self._degrade('CAMERA_UNAVAILABLE' if self.camera.status != 'ended' else 'STREAM_ENDED')
                time.sleep(0.01); continue
            last_seq = seq; n += 1; self.frames += 1; k += 1
            if time.time() - tick >= 2: self.fps = k / (time.time() - tick); tick, k = time.time(), 0
            if not self.detector.ready:
                self._degrade('MODEL_UNAVAILABLE'); self._publish(frame, None); continue
            if n % max(1, int(self.cfg['inference']['every_n_frames'])) == 0:
                try:
                    self.dets = self.detector.predict(frame)
                except Exception as e:                           # noqa: BLE001
                    log.error('inference failed: %s', e); self._degrade('INFERENCE_ERROR'); continue
                self.inferences += 1; self.inf_ms.append(self.detector.last_ms)
                for d in self.dets: self.class_counts[d.name] += 1
                self.state = self.engine.update(self.dets); self.system_state = self.state.level
                ann = draw(frame.copy(), self.dets, self.detector.classes)
                eid = self.alerts.handle(self.state, ann)
                if eid:     # advisory second opinion, queued in the background; never delays or changes detection
                    ctx = f'{self.state.level} {self.state.hazard}: ' + ', '.join(f'{d.name} {d.conf:.2f}' for d in self.dets[:5])
                    self.mllm.submit(frame, ctx, lambda r, eid=eid: self.store.set_mllm(eid, r), kind='event')
            self._publish(frame, self.state)

    def _degrade(self, why):
        # A broken camera/model must never read as "safe".
        if self.system_state != why:
            log.error('system state -> %s', why)
        self.system_state = why; self.engine.reset(); self.state = None; self.dets = []
        if why in ('CAMERA_UNAVAILABLE', 'STREAM_ENDED'):
            import cv2, numpy as np
            img = np.zeros((360, 640, 3), np.uint8)
            cv2.putText(img, why.replace('_', ' '), (40, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 215, 255), 2)
            self._store(img)

    def _publish(self, frame, state):
        import cv2
        img = draw(frame.copy(), self.dets, self.detector.classes)
        label = self.system_state.replace('_', ' ')
        col = LEVEL_COLOR.get(self.system_state, (0, 140, 255))
        cv2.rectangle(img, (0, 0), (img.shape[1], 30), col, -1)
        cv2.putText(img, label, (8, 21), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)
        self._store(img)

    def _store(self, img):
        import cv2
        ok, buf = cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, self.cfg['server']['jpeg_quality']])
        if ok:
            with self.lock: self.jpeg = buf.tobytes()

    def status(self):
        vm = psutil.virtual_memory()
        return dict(system_state=self.system_state, risk=self.state.to_dict() if self.state else None,
                    camera=dict(status=self.camera.status, error=self.camera.error, reconnects=self.camera.reconnects),
                    model=dict(ready=self.detector.ready, error=self.detector.error, path=self.cfg['model']['path'],
                               imgsz=getattr(self.detector, 'imgsz', None), meta=self.detector.meta),
                    stats=dict(frames=self.frames, inferences=self.inferences, capture_fps=round(self.fps, 1),
                               inference_ms_avg=round(sum(self.inf_ms) / len(self.inf_ms), 1) if self.inf_ms else None,
                               uptime_s=int(time.time() - self.t0), detections_by_class=dict(self.class_counts),
                               events_by_level=self.store.counts()),
                    system=dict(cpu_percent=psutil.cpu_percent(), ram_percent=vm.percent, ram_used_mb=round(vm.used / 1e6),
                                process_rss_mb=round(self.proc.memory_info().rss / 1e6), temp_c=pi_temp()),
                    mllm=self.mllm.status(), inbox=self.inbox.status(),
                    thresholds={k: self.cfg['risk'][k] for k in TUNABLE}, every_n_frames=self.cfg['inference']['every_n_frames'])


def create_app(config_path=os.path.join(BASE, 'config.yaml'), start_pipeline=True):
    cfg = load_config(config_path)
    app = Flask(__name__, static_folder=None)
    app.pipeline = pl = Pipeline(cfg)
    app.cfg = cfg
    token = os.environ.get(cfg['server'].get('auth_token_env', ''), '')
    ov_dir = os.path.join(os.path.dirname(os.path.abspath(config_path)), 'logs')

    @app.get('/')
    def index():
        return send_from_directory(os.path.join(BASE, 'dashboard'), 'index.html')

    @app.get('/health')
    def health():
        return jsonify(ok=True, system_state=pl.system_state)

    @app.get('/api/status')
    def status():
        return jsonify(pl.status())

    @app.get('/api/events')
    def events():
        return jsonify(pl.store.recent(min(int(request.args.get('n', 50)), 500)))

    app.config['MAX_CONTENT_LENGTH'] = 60 * 1024 * 1024

    @app.get('/api/inbox')
    def inbox_list():
        return jsonify(dict(status=pl.inbox.status(), results=pl.inbox.results(int(request.args.get('n', 20)))))

    @app.post('/api/inbox/upload')
    def inbox_upload():
        if token and not hmac.compare_digest(request.headers.get('X-Auth-Token', ''), token):
            abort(401)
        saved, rejected = [], []
        for f in request.files.getlist('file'):
            name = secure_filename(f.filename or '')
            if os.path.splitext(name)[1].lower() not in EXT:
                rejected.append(f.filename); continue
            tmp = os.path.join(pl.inbox.inbox, name + '.part'); f.save(tmp)
            import cv2, numpy as np
            if cv2.imdecode(np.fromfile(tmp, np.uint8), cv2.IMREAD_COLOR) is None:
                os.remove(tmp); rejected.append(f.filename); continue
            dst = os.path.join(pl.inbox.inbox, f'{int(time.time())}_{name}'); os.replace(tmp, dst); saved.append(os.path.basename(dst))
        return jsonify(saved=saved, rejected=rejected), (200 if saved else 400)

    @app.get('/outbox/<path:name>')
    def outbox_file(name):
        if not name.endswith(('.jpg', '.json')): abort(404)
        return send_from_directory(pl.inbox.outbox, name)

    @app.get('/snapshots/<path:name>')
    def snap(name):
        return send_from_directory(os.path.join(BASE, cfg['alerts']['snapshot_dir']), name)

    @app.route('/api/config', methods=['GET', 'POST'])
    def config():
        if request.method == 'GET':
            return jsonify(pl.status()['thresholds'])
        if token and not hmac.compare_digest(request.headers.get('X-Auth-Token', ''), token):
            abort(401)
        body = request.get_json(silent=True) or {}
        new = dict(cfg['risk'])
        for k, v in body.items():
            if k not in TUNABLE: return jsonify(error=f'unknown setting {k}'), 400
            lo, hi = TUNABLE[k]
            if not isinstance(v, (int, float)) or not lo <= v <= hi: return jsonify(error=f'{k} must be in [{lo}, {hi}]'), 400
            new[k] = type(cfg['risk'][k])(v)
        if new['uncertain_conf'] > min(new['low_conf'], new['high_conf']):
            return jsonify(error='uncertain_conf must not exceed low_conf/high_conf'), 400
        cfg['risk'].update(new); pl.engine.update_config(cfg['risk'])
        os.makedirs(ov_dir, exist_ok=True)
        json.dump({k: cfg['risk'][k] for k in TUNABLE}, open(os.path.join(ov_dir, 'runtime_overrides.json'), 'w'))
        return jsonify(pl.status()['thresholds'])

    @app.get('/video_feed')
    def video_feed():
        def gen():
            last = None
            while not pl.stop_evt.is_set():
                with pl.lock: j = pl.jpeg
                if j is not None and j is not last:
                    last = j; yield b'--f\r\nContent-Type: image/jpeg\r\n\r\n' + j + b'\r\n'
                time.sleep(0.05)
        return Response(gen(), mimetype='multipart/x-mixed-replace; boundary=f')

    if start_pipeline:
        pl.start()
    return app


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--config', default=os.path.join(BASE, 'config.yaml'))
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
    app = create_app(a.config)
    from werkzeug.serving import make_server
    srv = make_server(app.cfg['server']['host'], app.cfg['server']['port'], app, threaded=True)
    def bye(*_):
        log.info('shutting down'); threading.Thread(target=srv.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, bye); signal.signal(signal.SIGINT, bye)
    log.info('EDGEGUARD AI listening on %s:%s', app.cfg['server']['host'], app.cfg['server']['port'])
    try:
        srv.serve_forever()
    finally:
        app.pipeline.stop(); log.info('stopped')


if __name__ == '__main__':
    main()
