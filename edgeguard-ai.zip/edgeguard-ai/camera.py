"""Threaded camera reader with automatic recovery. Supports USB/V4L2, video files/RTSP, and Pi CSI (picamera2)."""
import logging, threading, time
import numpy as np

log = logging.getLogger('edgeguard.camera')


class Camera:
    def __init__(self, cfg):
        self.cfg = cfg
        self._frame = None; self._ts = 0.0; self._seq = 0
        self._lock = threading.Lock(); self._stop = threading.Event()
        self.status = 'starting'; self.error = None; self.reconnects = 0; self.eof = False
        self._t = threading.Thread(target=self._run, name='camera', daemon=True)

    def start(self):
        self._t.start(); return self

    def stop(self):
        self._stop.set(); self._t.join(timeout=3)

    def _open(self):
        src = self.cfg['source']
        if src == 'picamera2':
            from picamera2 import Picamera2
            cam = Picamera2()
            cam.configure(cam.create_video_configuration(main={'size': (self.cfg['width'], self.cfg['height']), 'format': 'RGB888'}))
            cam.start()
            return ('pi', cam)
        import cv2
        cap = cv2.VideoCapture(int(src) if str(src).isdigit() else src)
        if not cap.isOpened():
            raise RuntimeError(f'cannot open camera source {src!r}')
        if str(src).isdigit():
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.cfg['width']); cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.cfg['height'])
            cap.set(cv2.CAP_PROP_FPS, self.cfg['fps']); cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        return ('cv', cap)

    def _read(self, h):
        kind, obj = h
        if kind == 'pi':
            return True, np.ascontiguousarray(obj.capture_array()[:, :, ::-1])   # RGB -> BGR
        return obj.read()

    @staticmethod
    def _close(h):
        try:
            h[1].stop() if h[0] == 'pi' else h[1].release()
        except Exception:                                      # noqa: BLE001
            pass

    def _run(self):
        delay = self.cfg.get('reconnect_delay_s', 2.0); h = None
        is_file = not str(self.cfg['source']).isdigit() and self.cfg['source'] != 'picamera2' \
            and not str(self.cfg['source']).startswith(('rtsp://', 'http'))
        period = 1.0 / max(1, self.cfg.get('fps', 15))
        while not self._stop.is_set():
            try:
                if h is None:
                    h = self._open(); self.status = 'ok'; self.error = None; delay = self.cfg.get('reconnect_delay_s', 2.0)
                ok, f = self._read(h)
                if not ok or f is None:
                    if is_file and self.cfg.get('loop'):
                        self._close(h); h = None; continue
                    if is_file:
                        self.eof = True; self.status = 'ended'; self._close(h); return
                    raise RuntimeError('camera returned no frame')
                with self._lock:
                    self._frame, self._ts, self._seq = f, time.time(), self._seq + 1
                if is_file:
                    time.sleep(period)
            except Exception as e:                              # noqa: BLE001 - recover from any camera fault
                self.status, self.error = 'reconnecting', str(e)
                log.warning('camera error: %s (retry in %.1fs)', e, delay)
                if h: self._close(h); h = None
                self.reconnects += 1
                if self._stop.wait(delay): break
                delay = min(delay * 2, self.cfg.get('max_reconnect_delay_s', 30.0))
        if h: self._close(h)

    def read(self):
        """Return (frame copy | None, age_seconds, seq)."""
        with self._lock:
            if self._frame is None:
                return None, float('inf'), self._seq
            return self._frame.copy(), time.time() - self._ts, self._seq
