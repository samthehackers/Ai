#!/usr/bin/env bash
# Stores your OpenRouter API key for the online LLM (used only when the Pi has internet). Never typed into the web UI.
set -euo pipefail
cd "$(dirname "$0")/.."
read -r -s -p "OpenRouter API key: " K; echo
[ -n "$K" ] || { echo "empty key"; exit 1; }
touch edgeguard.env; chmod 600 edgeguard.env; sed -i '/^OPENROUTER_API_KEY=/d' edgeguard.env; echo "OPENROUTER_API_KEY=$K" >> edgeguard.env
echo "Saved. NOTE: with a key set, alert snapshots and dropped images are sent to OpenRouter when online. Restart: sudo systemctl restart edgeguard"
